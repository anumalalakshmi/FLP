package com.cg.capstore.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cg.capstore.bean.Products;

public interface IProdRepo extends CrudRepository<Products, Integer> {
	
//	public List<Products> findAll();
//	
//	public List<Products> updateProduct(float price);

}
