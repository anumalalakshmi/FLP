package com.cg.capstore.repo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.capstore.bean.Products;

public class ProdRepoImpl {

	EntityManager entity;

	public List<Products> updateProduct(float price) {
		List<Products> list = new ArrayList<>();
		Query q = entity.createQuery("update Products set discount_price=" + price);
		return q.getResultList();
	}

	public List<Products> findAll() {
		Query q = entity.createQuery("select * from Products");
		return q.getResultList();
	}

}
