package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.bean.Products;


public interface ProductService {
	
	public Iterable<Products> showProducts() ;

	//public void save(Products p);

	public List<Products> findAll();
	
	public List<Products> updateProduct(Products p);


	

}
