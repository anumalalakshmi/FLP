package com.cg.capstore.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Products;
import com.cg.capstore.repo.IProdRepo;
import com.cg.capstore.repo.ProdRepoImpl;


@Service
@Transactional
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	IProdRepo repo;
	@Autowired
	EntityManager entity;
	
	
	public Iterable<Products> showProducts() {
		return repo.findAll();

	}

//	@Override
//	public void save(Products p) {
//		repo.save(p);
//	}

	@Override
	public List<Products> findAll() {
		 List<Products> list = new ArrayList<>(); 
		repo.findAll().forEach(list::add);
		return list;
	}
	
	public List<Products> updateProduct(Products p) {
		entity.persist(p);
		Query q = entity.createQuery("from Products");
		return q.getResultList();
	}

	
	

}
